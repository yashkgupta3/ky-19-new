A Pen created at CodePen.io. You can find this one at https://codepen.io/radixzz/pen/pLrEgJ.

 3d Hex Mosaic made with three.js